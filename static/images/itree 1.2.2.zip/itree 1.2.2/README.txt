var : 1.2.2
Developed by : Hossein Rahmani
Release Date: 2012-10-29
The MIT License (MIT)
Copyright (c) 2012 Hossein Rahmani

changes from ver 1.2.1

1-other images like plus and dotted lines are added to options.

Changes from ver 1.0

1-childs property in nodes json is not required for no child nodes.
2-you can set ltotal option to -1 for expand all nodes.
3-the second time that you expand a load on demand node its shows the loaded nodes in first time expand and dont call load on demand function again.
4-you should not pass all options as a parameter to "itree.fill()" method, just those that have difference from default options.


