Homepage title: Visual-Blast Magazine - Free web design resources for designers and web developers
Homepage URL: www.visual-blast.com

Icon Title: Free PSD Icons - 'Bimbilini' Blogging Icons Set
Icon release URL: http://www.visual-blast.com/graphics/icons/free-psd-icons-blogging-icon-set-bimbilini/

Icons Description: A set of 36 beautiful, crisp and clear, high quality icons in 64�64px, 48�48px and 32�32px resoulution, available in .PNG and .PSD format. The set is built with bloggers in mind, contains the most popular social icons and other frequently used icons like RSS icon, RSS email, home, article, search, comments, user comment, chart, shopping cart, calendar, thumbs up/down and more.
Source PSD files are layered, so you can easily copy/paste icon design elements and create custom icons like �add user� or �delete user�.

License: 'Bimbilini' Blogging Icons Set is released free of charge, for both your private and commercial projects.
Release for Download, redistribution of these icons on an another site, or direct linking to the download location is prohibited. The icons can not be resold in any way.
If you like this free icons release, please link to the article (http://www.visual-blast.com/graphics/icons/free-psd-icons-blogging-icon-set-bimbilini/) and spread the word over the social sites.

Thank You!
Ivan M.
www.visual-blast.com